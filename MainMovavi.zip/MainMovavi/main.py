from flask import Flask, url_for, request, render_template
from utils import *

app = Flask(__name__)



# основная страница

@app.route('/')
def index():
    games = get_all_games()
    return render_template('index.html', games = data)


# страница игры

@app.route('/games/<int:game_id>')
def game_page(game_id):
   print(game.id, type(game_id))
   game = get_game_by_id(game_id)
   return render_template('game.html', game = game)

if __name__ == '__main__':
  app.run(host='0.0.0.0', port=80, debug=True)
