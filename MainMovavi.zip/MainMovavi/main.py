from flask import Flask, url_for, request, render_template, redirect
from utils import *

app = Flask(__name__)



# основная страница

@app.route('/')
def index():
  d = get_all_games()
  return render_template('index.html', games = d)


# страница игры с обсуждениями

@app.route('/games/<int:game_id>')
def game_page(game_id):
  g = get_game_by_id(game_id)
  discus = list_discussions()
  return render_template('game.html', game = g, discussions = discus)


#

@app.route('/add_game', methods = ['GET','POST'])
def add():
    if request.method == 'GET':
        return render_template('add_game.html')
    elif request.method == 'POST': 
        name = request.form.get('name')
        date_release = request.form.get('date_release')
        info = request.form.get('info')
        poster = request.form.get('poster')

        add_game(

            name,
            date_release,
            info,
            poster

            )
        return render_template("add_game.html")


@app.route('/add_discussion', methods = ['GET','POST'])
def add2():
    if request.method == 'GET':
        return render_template('add_discussion.html')
    elif request.method == 'POST': 
        name = request.form.get('discussion_name')
        info = request.form.get('discussion_info')

        add_discussion(

            name,
            info

            )
        return redirect("/")



if __name__ == '__main__':
  app.run(host='0.0.0.0', port=80, debug=True)
