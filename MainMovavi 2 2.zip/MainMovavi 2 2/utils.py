from sqlalchemy.orm import declarative_base, relationship, sessionmaker, session
from sqlalchemy import Integer, String, ForeignKey, Column, DateTime, create_engine
import hashlib
from flask import session as log_session
import os

BaseModel = declarative_base()

db_path = os.path.abspath("static/data/database.db")
engine = create_engine(f"sqlite:///{db_path}")

# создаем таблицу с пользователями

class User(BaseModel):
    __tablename__ = 'user'
    
    id = Column(Integer, primary_key=True)
    user_name = Column(String)
    user_info = Column(String(100))
    user_password = Column(String)
    user_avatar = Column(String)

    discussions = relationship("Discussion", back_populates="user")
    answers = relationship("Answer", back_populates="user")

# создаем таблицу с играми

class Game(BaseModel):
    __tablename__ = 'game'
    
    id = Column(Integer, primary_key=True)
    game_name = Column(String)
    game_info = Column(String)
    game_poster = Column(String)
    game_date_release = Column(Integer)

    discussions = relationship("Discussion", back_populates="game")

# создаем таблицу с обсуждениями

class Discussion(BaseModel):
    __tablename__ = 'discussion'
    
    id = Column(Integer, primary_key=True)
    discussion_name = Column(String(50))
    discussion_info = Column(String)
    
    game_id = Column(Integer, ForeignKey('game.id'))
    user_id = Column(Integer, ForeignKey('user.id'))

    game = relationship("Game", back_populates="discussions")
    user = relationship("User", back_populates="discussions")

# создаем таблицу с ответами

class Answer(BaseModel):
    __tablename__ = 'answer'
    
    id = Column(Integer, primary_key=True)
    answer_info = Column(String)
    
    discussion_id = Column(Integer, ForeignKey('discussion.id'))
    user_id = Column(Integer, ForeignKey('user.id'))
    user = relationship("User", back_populates="answers")






BaseModel.metadata.create_all(engine)

Session = sessionmaker(bind=engine)

session = Session()

# создаем функцию для регистрации

def register(name, password, info, avatar):

    # если log_session == 0 значит не зарегистрирован 
    log_session['regist'] = 0

    salt = os.urandom(32)
    print(password) 
    password_rough = password
    key = hashlib.pbkdf2_hmac(
        'sha256', # Используемый алгоритм хеширования
        password.encode('utf-8'), # Конвертируется пароль в байты
        salt, # Предоставляется соль
        500000 # Рекомендуется использовать хотя бы 100000 итераций SHA-256
    )
    password_final = salt + key 

    if User.user_name != name and User.user_password != password:
        new_user = User(user_name = name, user_info = info, user_password = password_final, user_avatar = avatar)
        log_session['regist'] = 1

    elif User.user_name == name and User.user_password == password:
        log_session['regist'] = 1

    else:
        '<script>alert("Error")<script>'
        log_session['regist'] = 0
    session.add(new_user)
    session.commit()

    user = session.query(User).filter(User.user_name == name).first()
    log_session['id'] = user.id


# создаем функцию для добавления игры

def add_game(name, date_release, info, poster):
    new_game = Game(game_name = name, game_date_release = date_release, game_info = info, game_poster = poster)
    session.add(new_game)
    session.commit()


# создаем функцию для добавления обсуждения

def add_discussion(name, game_id, info):
    new_discussion = Discussion(discussion_name = name, game_id = game_id, discussion_info = info)
    session.add(new_discussion)
    session.commit()


# создаем функцию для создания списка обсуждений

def list_discussions_that_game(game_id):
    discussions = []
    discussions = session.query(Discussion).filter(Discussion.game_id == game_id).all()
    return discussions


# создаем функцию для нахождения юзера

def get_user_by_id(user_id):
    user = session.query(User).filter(User.id == user_id).first()
    return user


# создаем функцию для создания списка ответов

def list_answers_that_discussion(discussion_id):
    answers = []
    answers = session.query(Answer).filter(Answer.discussion_id == discussion_id).all()
    return answers


# создаем функцию для добавления ответа

def add_answer(discussion_id, info):
    new_answer = Answer(discussion_id = discussion_id, answer_info = info)
    session.add(new_answer)
    session.commit()


# берем все игры из базы данных

def get_all_games():
    data = []
    data = session.query(Game).all()
    return data


# находим игру по айди

def get_game_by_id(game_id):
    game = []
    game = session.query(Game).filter(Game.id == game_id).first()
    return game


# находим обсуждение по айди 

def get_discussion_by_id(discussion_id):
    return session.query(Discussion).filter(Discussion.id == discussion_id).first()


def get_all_users():
    return session.query(User).all()

#   {% if session['regist'] == 0 %}
#   <script>window.location.replace("/add_user");</script>
#   {% else %}