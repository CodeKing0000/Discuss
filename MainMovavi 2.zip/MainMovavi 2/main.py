from flask import Flask, url_for, request, render_template, redirect, session as log_session
from utils import *

app = Flask(__name__)

app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'


# основная страница

@app.route('/')
def index():
  if log_session[ 'regist' ] == 0:
    log_session['user_id'] = None
  d = get_all_games()
  u = get_all_users()
  return render_template('index.html', users = u,  games = d, log_session = log_session)


# страница игры с обсуждениями

@app.route('/games/<int:game_id>')
def game_page(game_id):
  g = get_game_by_id(game_id)
  disc = list_discussions_that_game(game_id)
  return render_template('game.html', game = g, discussions = disc, log_session = log_session)


# страница обсуждения с ответами

@app.route('/discussion/<int:discussion_id>')
def discussion_page(discussion_id):
  print(discussion_id)
  d = get_discussion_by_id(discussion_id)
  answers = list_answers_that_discussion(discussion_id)
  return render_template('discussion.html', discussion = d, answers = answers)


# страница профиля юзера

@app.route('/users/<int:user_id>')
def user_page(user_id):
  user = get_user_by_id(user_id)
  return render_template('user.html', user = user, name = user.name, avatar = user.avatar, info = user.info, log_session = log_session)


# форма для игры 

@app.route('/add_game', methods = ['GET','POST'])
def add():
    if request.method == 'GET':
        return render_template('add_game.html')
    elif request.method == 'POST': 
        name = request.form.get('game_name')
        date_release = request.form.get('game_date_release')
        info = request.form.get('game_info')
        poster = request.form.get('game_poster')

        add_game(

            name,
            date_release,
            info,
            poster

            )
        return redirect("/")


# форма для ответа

@app.route('/add_discussion/<int:discussion_id>', methods = ['GET','POST'])
def add2():
    
    if request.method == 'GET':
        return render_template('add_discussion.html')
    elif request.method == 'POST': 
        name = request.form.get('name')
        game_id = request.form.get('game_id')
        info = request.form.get('info')

        add_answer(

            name,
            game_id,
            info

            )
        
        return redirect("/")


# форма для обсуждения

@app.route('/add_discussion', methods = ['GET','POST'])
def add3():
    if request.method == 'GET':
        game_id = int(request.args.get('game'))
        g = get_game_by_id(game_id)
        print(g.id)
        return render_template('add_discussion.html', game = g)
    elif request.method == 'POST': 
        discussion_name = request.form.get('name')
        game_id = request.form.get('game_id')
        info = request.form.get('info')

        add_discussion(
            
            discussion_name,
            game_id,
            info

            )
        
        return redirect("/")
    

# форма для пользователя

@app.route('/add_user', methods = ['GET','POST'])
def add4():
    if request.method == 'GET':
        return render_template('add_user.html')
    elif request.method == 'POST': 
        name = request.form.get('name')
        info = request.form.get('info')
        password = request.form.get('password')
        avatar = request.form.get('avatar')

        register(
           
            name,
            password,
            info,
            avatar

            )
        return redirect("/")
    

@app.context_processor
def any_data_processor():
  return dict(log_session=log_session)


if __name__ == '__main__':
  app.run(host='0.0.0.0', port=80, debug=True)
